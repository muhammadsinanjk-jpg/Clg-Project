from django.shortcuts import render
from add_product.models import AddProduct
# Create your views here.
def admin(request):
    return render(request,'temp/admin.html')
def buyer(request):
    categories = Catagory.objects.all()  # Fetch all categories
    return render(request, 'temp/buyer.html', {'categories': categories})
    # return render(request,'temp/buyer.html')
def seller(request):
    return render(request,'temp/seller.html')

# views.py
from django.shortcuts import render
from catagory.models import Catagory

def home(request):
    categories = Catagory.objects.all()  # Fetch all categories
    return render(request, 'temp/home.html', {'categories': categories})
from django.shortcuts import render, get_object_or_404
from add_product.models import AddProduct, Catagory

# Category page
from django.shortcuts import render, get_object_or_404
from add_product.models import AddProduct, Catagory

# Products by catagory
def products_by_category(request, cat_name):
    categories = Catagory.objects.all()
    products = AddProduct.objects.filter(cat__catagory=cat_name)
    context = {
        'd': products,
        'categories': categories,
        'selected_category': cat_name
    }
    return render(request, 'temp/view_products.html', context)

# Single product detail page
def product_detail(request, pro_id):
    product = get_object_or_404(AddProduct, pk=pro_id)
    categories = Catagory.objects.all()  # optional: for nav bar or catagory list
    context = {
        'product': product,
        'categories': categories
    }
    return render(request, 'temp/product_details.html', context)
