from django.urls import path,re_path
from add_product import views

urlpatterns=[
    path('product/',views.add),
    path('v_product/',views.view),
    path('up_view/',views.view_up),
    re_path('update/(?P<idd>\w+)',views.update),
    re_path('del/(?P<idd>\w+)', views.delete),
    path('ajax_add_to_cart/', views.ajax_add_to_cart, name='ajax_add_to_cart'),
]