
from django.shortcuts import render, redirect, get_object_or_404
from .models import Cart, Order
from add_product.models import AddProduct

# View Cart
from django.shortcuts import render, redirect, get_object_or_404
from cart.models import Cart, Order
from add_product.models import AddProduct
import json
from django.shortcuts import render, redirect, get_object_or_404
from .models import Cart, Order

# -------------------------
# View Cart
# -------------------------
def view_cart(request):
    ss = request.session['u_id']
    carts = Cart.objects.filter(reg_id=ss)

    cart_total = sum(item.pro.product_price for item in carts)

    return render(request, 'cart/cartpost.html', {
        'ca': carts,
        'cart_total': cart_total
    })

# -------------------------
# Place Order
# -------------------------
from django.shortcuts import render, redirect
from cart.models import Cart, Order
from payment.models import Payment
import json
from django.contrib import messages
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Cart, Order
from register_for_buyer.models import RegisterForBuyer  # Import the buyer model
import json

import json
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from cart.models import Cart, Order
from register_for_buyer.models import RegisterForBuyer

def order(request):
    # 1️⃣ Check if user is logged in
    uid = request.session.get('u_id')
    if not uid:
        messages.error(request, "Please login first")
        return redirect('/login/')  # Replace with your login URL

    # 2️⃣ Get the buyer object
    buyer = get_object_or_404(RegisterForBuyer, reg_id=uid)

    # 3️⃣ Get cart data from GET or POST
    cart_data = request.GET.get('cart_data') or request.POST.get('cart_data')
    if not cart_data:
        messages.error(request, "No cart items found")
        return redirect('/cart/')  # Replace with your cart URL

    try:
        cart_items_data = json.loads(cart_data)
    except json.JSONDecodeError:
        messages.error(request, "Invalid cart data")
        return redirect('/cart/')

    cart_items = []
    grand_total = 0

    # 4️⃣ Prepare cart items and calculate total
    for item in cart_items_data:
        cart_item = get_object_or_404(Cart, cart_id=item['cart_id'], reg_id=uid)
        quantity = int(item.get('quantity', 1))
        amount = cart_item.pro.product_price * quantity
        cart_items.append({
            'product': cart_item.pro,
            'quantity': quantity,
            'amount': amount,
        })
        grand_total += amount


    request.session['gtot']=grand_total

    # 5️⃣ If POST, process the order
    if request.method == "POST":
        delivery_address = request.POST.get('delivery_address')
        if not delivery_address:
            messages.error(request, "Please enter a delivery address")
            return render(request, 'cart/order.html', {'products': cart_items, 'grand_total': grand_total})

        # Save orders
        first_order_id = None
        for p in cart_items:
            order_obj = Order.objects.create(
                pro=p['product'],
                reg=buyer,  # Use ForeignKey object
                quantity=p['quantity'],
                amount=p['amount'],
                delivery_address=delivery_address
            )
            if first_order_id is None:
                first_order_id = order_obj.order_id

            # Update product stock
            p['product'].stock_quantity -= p['quantity']
            p['product'].save()

        # Clear cart
        for item in cart_items_data:
            ci = get_object_or_404(Cart, cart_id=item['cart_id'], reg_id=uid)
            ci.delete()

        # Redirect to payment page
        return redirect('payment', order_id=first_order_id)

    # 6️⃣ If GET, show order summary page
    return render(request, 'cart/order.html', {'products': cart_items, 'grand_total': grand_total})


def delete(request,idd):
    obj=Cart.objects.get(cart_id=idd)
    obj.delete()
    return view_cart(request)
#
# def view_order(request,idd):
#     obj = Order.objects.filter(order_id=idd)
#     c={
#         'p':obj
#     }
#
#     return render(request, 'cart/view_order.html',c)
#

from django.shortcuts import render, redirect
from cart.models import Order

def view_order(request, idd):
    obj = Order.objects.filter(order_id=idd)

    if request.method == "POST":
        address = request.POST.get("delivery_address")

        order = Order.objects.get(order_id=idd)
        order.delivery_address = address
        order.save()

        # Redirect to the new payment page
        return redirect('payment_page', order_id=idd)

    return render(request, 'cart/view_order.html', {'p': obj})

